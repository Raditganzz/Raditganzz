ROR BANG :v

WhatsApp : https://wa.me/6285394265968
Instagram : https://www.instagram.com/irulzgoodboy_/
YouTube : https://www.youtube.com/@irulz.777_

Please don't delete names Thanks !! If you want to add please !!
Please Ya Ror 😁☝
 
### `THANKS`
- Telegraf & Telegram
- My God
- Ditz Developer
- [My Mastah](https://github.com/zeeoneofficial/Telebot)
- And all Support.
